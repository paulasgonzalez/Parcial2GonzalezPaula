package modelo;

public enum Categoria {
    EXPLORACION,
    CARGA,
    MILITAR
}
