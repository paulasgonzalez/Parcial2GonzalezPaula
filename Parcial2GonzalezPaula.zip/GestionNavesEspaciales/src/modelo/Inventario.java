package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario <T> implements Serializable{
    private static final Long serialVersionUID = 1L;
    List<T> lista = new ArrayList<>();
    
    public void agregar(T elemento){
        if(elemento == null){
            throw new IllegalArgumentException("No se puede agregar algo nulo");
        }
        lista.add(elemento);
    }
    
    public void eliminar(int indice){
        validarIndice(indice);
        lista.remove(indice);
    }
    
    
    private void validarIndice(int indice){
        if(!(indice > 0 && indice < lista.size())){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    
    public Iterator <T> iterator(Comparator<? super T> comparador){
        List<T> aux = new ArrayList<>(lista);
        aux.sort(comparador);
        return aux.iterator();
    }
    
    
    public void ordenarElementos(Comparator<? super T> comparador){
        Iterator <T> it = iterator(comparador);
        while (it.hasNext()){
            System.out.println(it.next());
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T item: lista){
            accion.accept(item);
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item: lista){
            if(criterio.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }
    
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> aux = new ArrayList<>();
        for(T item: lista){
            aux.add(transformacion.apply(item)); 
        }
        return aux;
    }
    
    public void guardarEnArchivo(String nombreArchivo) {
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(nombreArchivo))){
            salida.writeObject(lista);

        }catch (IOException ex){
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }

    public List<T> cargarDesdeArchivo(String nombreArchivo) {
        List<T> toReturn = null;
            try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(nombreArchivo))){
                 toReturn = (List<T>) entrada.readObject();

            } catch (IOException | ClassNotFoundException ex){
                System.out.println(ex.getMessage());
            }
        return toReturn;
    }
    
    
    public void guardarEnCSV(String nombreArchivo){
        File archivo = new File(nombreArchivo);
            try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
                bw.write("id,nombre,categoria,capacidad\n");
                for(Object o: lista){
                    if(o instanceof NaveEspacial n)
                        bw.write(n.toCSV() + "\n");
                    }
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
    }

    
    public List<T> cargarDesdeCSV(String nombreArchivo) {
        List<T> toReturn = new ArrayList<>();
        File archivo = new File(nombreArchivo);
        
        try(BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null){
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length() - 1);
                }
                toReturn.add((T) NaveEspacial.fromCSV(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }    
    
}
