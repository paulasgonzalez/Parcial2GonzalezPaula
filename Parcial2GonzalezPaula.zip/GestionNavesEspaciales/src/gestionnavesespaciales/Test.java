package gestionnavesespaciales;

import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import modelo.Categoria;
import modelo.Inventario;
import modelo.NaveEspacial;

public class Test {


    public static void main(String[] args) {
    
        
        // Crear un inventario de naves espaciales
        Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
        
        inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", Categoria.CARGA, 100));
        inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", Categoria.EXPLORACION, 50));
        inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", Categoria.MILITAR, 420));
        inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", Categoria.MILITAR, 300));
        inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", Categoria.CARGA, 210));
        inventarioNaves.agregar(new NaveEspacial(6, "Aurora", Categoria.EXPLORACION, 780));
        
        // Mostrar todas las naves en el inventario
        System.out.println("Inventario de naves espaciales:"); 
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));
        System.out.println("-------------");
        
        // Filtrar naves por categoria (MILITAR)
        System.out.println("\nNaves de la categoria MILITAR:");
        Predicate<NaveEspacial> criterio = p -> p.getCategoria().equals(Categoria.MILITAR);
        inventarioNaves.filtrar(criterio).forEach(nave -> System.out.println(nave));
        System.out.println("---------------");
        
        // Filtrar naves cuyo nombre contiene "Falcon"
        System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
        List<NaveEspacial> navesFalcon = inventarioNaves.filtrar(p -> p.getNombre().contains("Falcon"));
        navesFalcon.forEach(System.out::println);
        System.out.println("-----------");
        
        // Transforme todas las naves para que tengan un tipo diferente.
        System.out.println("\nNaves transformadas en su categoria:");
        List<NaveEspacial> navesTransformadas = inventarioNaves.transformar(
                n -> {
                    n = new NaveEspacial(n.getId(), n.getNombre(), n.getCategoria(), n.getCapacidad());
                    if(!n.equals(Categoria.CARGA)){
                        n.setCategoria(Categoria.CARGA);
                    }
                    return n;
                }
        );
        navesTransformadas.forEach(System.out::println);
        System.out.println("-------------");
              
        // Ordenar naves de manera natural (por id)
        System.out.println("\nNaves ordenadas de manera natural (por id):");
        inventarioNaves.ordenarElementos(Comparator.naturalOrder());
        System.out.println("-------------");
        
        // Ordenar naves por nombre utilizando un Comparator
        System.out.println("\nNaves ordenadas por nombre (comparator):");
        inventarioNaves.ordenarElementos((n1, n2) -> n1.getNombre().compareTo(n2.getNombre()));
        
        System.out.println("-------------");
        // Guardar el inventario en un archivo binario
        inventarioNaves.guardarEnArchivo("src/data/naves.dat");

        // Cargar el inventario desde el archivo binario
        List<NaveEspacial> inventarioCargado = inventarioNaves.cargarDesdeArchivo("src/data/naves.dat");
        System.out.println("\nNaves cargadas desde archivo binario:");
        inventarioCargado.forEach(System.out::println);
        System.out.println("------------");
        
        // Guardar el inventario en un archivo CSV
        inventarioNaves.guardarEnCSV("src/data/naves.csv");
        
        // Cargar el inventario desde el archivo CSV
        inventarioNaves.cargarDesdeCSV("src/data/naves.csv");
        System.out.println("\nNaves cargadas desde archivo CSV:");
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));
                
        
        
        
    }
    
}
